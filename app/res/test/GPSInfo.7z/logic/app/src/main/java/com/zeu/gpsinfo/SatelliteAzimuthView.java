package com.zeu.gpsinfo;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.zeu.lib.gps.GpsLocation;

public class SatelliteAzimuthView extends ImageView {
	private List<GpsLocation.SatelliteInfo> mSatelliteInfos = new ArrayList<>();
	private Bitmap mBmpUsedSignal,mBmpGreenSignal,mBmpBadSignal;
	Paint paint = new Paint();

	public SatelliteAzimuthView(Context context) {
		this(context,null);
	}
	public SatelliteAzimuthView(Context context, AttributeSet attrs) {
		this(context,attrs,0);
	}
	public SatelliteAzimuthView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		mBmpUsedSignal = BitmapFactory.decodeResource(getResources(), R.drawable.sate1);
		mBmpGreenSignal = BitmapFactory.decodeResource(getResources(), R.drawable.sate2);
		mBmpBadSignal = BitmapFactory.decodeResource(getResources(), R.drawable.sate3);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.translate(getWidth()/2, getHeight()/2);
		for (GpsLocation.SatelliteInfo info : mSatelliteInfos) {
			if (info != null) {
				//此处必须将地球的半径减去卫星的半径,因为绘图是以卫星的左上角为原点的, 而不是以卫星的中心点为原点
				PointF pointF = info.getPosition(0, 0, getWidth()/2-mBmpUsedSignal.getWidth());
				if (info.used) {
					canvas.drawBitmap(mBmpUsedSignal, pointF.x, pointF.y, paint);
				} else {
					canvas.drawBitmap(info.isSignalAboveCritical() ? mBmpGreenSignal : mBmpBadSignal, pointF.x, pointF.y, paint);
				}
				paint.setColor(Color.WHITE);
				paint.setTextSize(10);
				canvas.drawText(info.getIdName(), pointF.x, pointF.y+mBmpGreenSignal.getHeight(), paint);
			}
		}
	}

	public void setSatInfo(GpsLocation.SatelliteInfo[] gpsSatList){
		mSatelliteInfos.clear();
		if (null != gpsSatList) {
			for (GpsLocation.SatelliteInfo satelliteInfo : gpsSatList) {
				mSatelliteInfos.add(satelliteInfo);
			}
		}
		invalidate();
	}
}
