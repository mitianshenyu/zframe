package com.zeu.gpsinfo;

import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zeu.frame.bind.Binders;
import com.zeu.frame.bind.Data;
import com.zeu.frame.bind.Packet;
import com.zeu.frame.bind.observer.IntegerObserver;
import com.zeu.frame.bind.observer.LongObserver;
import com.zeu.frame.bind.observer.PacketObserver;
import com.zeu.gpsinfo.model.GpsModel;
import com.zeu.gpsinfo.model.LocationInfo;
import com.zeu.gpsinfo.model.SatelliteInfo;
import com.zeu.lib.PermissionGrants;
import com.zeu.lib.gps.GpsLocation;
import com.zeu.lib.log.Slog;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    GpsModel mGpsModel = new GpsModel();
    SparseArray<TextView> mViews = new SparseArray<>();
    PermissionGrants mPermissionGrants;
    SatelliteAzimuthView mSatelliteAzimuthView;
    LinearLayout mSignalsLinearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (PermissionGrants.checkDynamicPermissionsRequested()) {
            mPermissionGrants = new PermissionGrants(this);
            mPermissionGrants.requestPermissions(11, "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION");
            mPermissionGrants.setOnPermissionResultCallback(new PermissionGrants.OnPermissionResultCallback() {
                @Override
                public void onAllPermissionResult(int requestCode, String[] permissions, int[] grantResults) {
                    if (mPermissionGrants.checkPermissionsDeniedForResult(grantResults, permissions,
                            "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION").size() == 2) {
                        //检测成功
                    }
                }

                @Override
                public void onPermissionResult(int requestCode, int index, String permission, int result) {
                    Slog.d(permission+":"+result);
                    startService(new Intent().setClassName(getPackageName(), GpsService.class.getName()));
                }
            });
        } else {
            startService(new Intent().setClassName(getPackageName(), GpsService.class.getName()));
        }

        mViews.put(R.id.latitude, (TextView) findViewById(R.id.latitude));
        mViews.put(R.id.longitude, (TextView) findViewById(R.id.longitude));
        mViews.put(R.id.accuracy, (TextView) findViewById(R.id.accuracy));
        mViews.put(R.id.sate_number, (TextView) findViewById(R.id.sate_number));
        mViews.put(R.id.used_number, (TextView) findViewById(R.id.used_number));
        mViews.put(R.id.location_time, (TextView) findViewById(R.id.location_time));
        mSatelliteAzimuthView = findViewById(R.id.ball);

        mSignalsLinearLayout = findViewById(R.id.signals);
        ViewGroup parentView = ((ViewGroup)mSignalsLinearLayout.getParent());
        parentView.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));

        mGpsModel.mLocationInfo.setLocationInfo(new GpsLocation.LocationInfo());
        mGpsModel.mLocationInfo.addObserver(true, new PacketObserver() {
            @Override
            public boolean onChanged(Packet packet, Packet packet1, Data data) {
                if (packet instanceof LocationInfo && null != ((LocationInfo) packet).mInfo) {
                    GpsLocation.LocationInfo info = ((LocationInfo) packet).mInfo;
                    mViews.get(R.id.latitude).setText(new DecimalFormat("0.0000").format(info.altitude));
                    mViews.get(R.id.longitude).setText(new DecimalFormat("0.0000").format(info.longitude));
                    mViews.get(R.id.accuracy).setText(new DecimalFormat("0.0000").format(info.accuracy));
                }
                return false;
            }
        });

        mGpsModel.mSatelliteInfo.addObserver(new PacketObserver() {
            @Override
            public boolean onChanged(Packet packet, Packet packet1, Data data) {
                if (packet instanceof SatelliteInfo) {
                    if (((SatelliteInfo) packet).mInfos != null && ((SatelliteInfo) packet).mInfos.length > 0) {
                        //12条记录, 左右间隔和记录条目大小一样
                        mSignalsLinearLayout.removeAllViews();
                        for (GpsLocation.SatelliteInfo satelliteInfo : ((SatelliteInfo) packet).mInfos) {
                            View signalLayout = LayoutInflater.from(mSignalsLinearLayout.getContext()).inflate(R.layout.signal, null);
                            if (null != signalLayout) {
                                SatelliteSignalView satelliteView = signalLayout.findViewById(R.id.satellite);
                                satelliteView.setSignal((int) satelliteInfo.snr);
                                TextView signalView = signalLayout.findViewById(R.id.signal);
                                signalView.setText(satelliteInfo.getIdName());

                                LinearLayout containerLayout = new LinearLayout(mSignalsLinearLayout.getContext());
                                containerLayout.setOrientation(LinearLayout.HORIZONTAL);
                                containerLayout.addView(new View(containerLayout.getContext()), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
                                containerLayout.addView(signalLayout, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 2));
                                containerLayout.addView(new View(containerLayout.getContext()), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

                                mSignalsLinearLayout.addView(containerLayout, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
                            }
                            Slog.d("SatelliteInfo:"+satelliteInfo);
                        }
                        mSatelliteAzimuthView.setSatInfo(((SatelliteInfo) packet).mInfos);
                    } else {

                    }
                }
                /*mViews.get(R.id.location_time).setText(""+info.altitude);*/
                return false;
            }
        });

        mGpsModel.mSatelliteUsedNumber.addObserver(true, new IntegerObserver() {
            @Override
            public boolean onChanged(int i, int i1, Data data) {
                mViews.get(R.id.used_number).setText(""+i);
                return false;
            }
        });

        mGpsModel.mSatelliteTotalNumber.addObserver(new IntegerObserver() {
            @Override
            public boolean onChanged(int i, int i1, Data data) {
                mViews.get(R.id.sate_number).setText(""+i);
                return false;
            }
        });

        mGpsModel.mLocationTime.addObserver(new LongObserver() {
            @Override
            public boolean onChanged(long l, long l1, Data data) {
                mViews.get(R.id.location_time).setText(String.format("%02d:%02d:%02d", l/3600, l/60, l%60));
                return false;
            }
        });
        /*mGpsModel.mLocationInfo.mInfo.altitude = 1.11;
        mGpsModel.mLocationInfo.notifyDataChangedAll();

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                mGpsModel.mLocationInfo.mInfo.altitude = SystemClock.elapsedRealtime();
                mGpsModel.mLocationInfo.notifyDataChangedAll();
            }
        }, 1000, 1000);*/
        Binders.attach(MainActivity.this, "com.zeu.gpsinfo", "com.zeu.gpsinfo.GpsService", "com.zeu.gpsinfo.GpsService.Ready");
    }

    @Override
    protected void onStart() {
        super.onStart();
        mGpsModel.attach(new Handler());
    }

    @Override
    protected void onStop() {
        mGpsModel.detach();
        super.onStop();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Slog.d("权限:"+requestCode);
        mPermissionGrants.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
