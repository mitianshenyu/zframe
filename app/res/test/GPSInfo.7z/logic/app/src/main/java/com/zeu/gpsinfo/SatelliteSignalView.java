package com.zeu.gpsinfo;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.zeu.lib.view.LayerDrawable;

public class SatelliteSignalView extends ImageView {
	LayerDrawable.Layer mSignalLayer;
	LayerDrawable.TextLayer mTextLayer;
	public SatelliteSignalView(Context context) {
		this(context,null);
	}
	public SatelliteSignalView(Context context, AttributeSet attrs) {
		this(context,attrs,0);
	}
	public SatelliteSignalView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		final LayerDrawable drawable = LayerDrawable.asBackground(this);
		drawable.drawRect(Color.GRAY,2);

		mSignalLayer = drawable.fillRect(Color.GREEN).setAlpha(1000).
				setAlign(LayerDrawable.Align.BOTTOM).
				setScale(1,0).
				setPadding(2, 2, 2, 2).
				invalidate();

		mTextLayer = drawable.drawText("Q", Color.RED, 30);
		mTextLayer.setAlign(LayerDrawable.Align.CENTER_HOR|LayerDrawable.Align.BOTTOM);
		mTextLayer.setPadding(0, 0, 0, 10);
	}

	public void setSignal(int level/*0~100*/) {
		mSignalLayer.setScale(1, level/100.0f).setColor(level<30?Color.RED:Color.BLUE);
		//mTextLayer.setScale(0, level/100.0f).getParent().drawText(""+level);
		mTextLayer.setScale(0, level/100.0f).draw(""+level);
	}
}
