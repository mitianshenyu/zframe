package com.zeu.gpsinfo.model;

import android.os.Handler;

import com.zeu.frame.bind.Boolean;
import com.zeu.frame.bind.Integer;
import com.zeu.frame.bind.Long;
import com.zeu.frame.bind.comm.Model;

/**
 * Created by zeu on 2017/12/19.
 */

public class GpsModel extends Model {
    //to logic
    public Boolean mShown = new Boolean("GpsModel.mShown", false);

    //to view
    public LocationInfo mLocationInfo = new LocationInfo("GpsModel.LocationInfo", false);
    public SatelliteInfo mSatelliteInfo = new SatelliteInfo("GpsModel.SatelliteInfo", false);
    public Integer mSatelliteTotalNumber = new Integer("GpsModel.mSatelliteTotalNumber", 0);
    public Integer mSatelliteUsedNumber = new Integer("GpsModel.mSatelliteUsedNumber", 0);
    public Long mLocationTime = new Long("GpsModel.mLocationTime", 0);

    @Override
    public void attach(String module, Handler handler) {
        super.attach(module, handler);
        mShown.set(true);
    }

    @Override
    public void detach(boolean clearAllObservers) {
        super.detach(clearAllObservers);
        mShown.set(false);
    }
}
