package com.zeu.gpsinfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.zeu.frame.bind.Packet;
import com.zeu.lib.gps.GpsLocation;

/**
 * Created by zeu on 2017/12/19.
 */

public class SatelliteInfo extends Packet {
    public GpsLocation.SatelliteInfo[] mInfos;
    public SatelliteInfo(String name, boolean attach) {
        super(name, null, attach);
    }

    public void setLocationInfo(GpsLocation.SatelliteInfo[] infos) {
        mInfos = infos;
        set(this);
    }

    public int getUsedSatelliteNumber() {
        int usedNumber = 0;
        if (null != mInfos) {
            for (GpsLocation.SatelliteInfo satelliteInfo : mInfos) {
                if (null != satelliteInfo && satelliteInfo.used) {
                    usedNumber++;
                }
            }
        }
        return usedNumber;
    }

    public int getTotalSatelliteNumber() {
        return null != mInfos ? mInfos.length : 0;
    }

    protected SatelliteInfo(Parcel in) {
        super(in);
        try {
            Parcelable[] parcelables = in.readParcelableArray(GpsLocation.SatelliteInfo.class.getClassLoader());
            if (null != parcelables) {
                GpsLocation.SatelliteInfo[] satelliteInfos = new GpsLocation.SatelliteInfo[parcelables.length];
                for (int i = 0; i < satelliteInfos.length; i++) {
                    Parcelable obj = parcelables[i];
                    satelliteInfos[i] = (obj instanceof GpsLocation.SatelliteInfo) ? (GpsLocation.SatelliteInfo)parcelables[i] : null;
                }
                mInfos = satelliteInfos;
            }
        } catch (Exception e) {
        }
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, 1);
        if(null != dest) {
            dest.writeParcelableArray(mInfos, 0);
        }
    }

    public SatelliteInfo copy(Object value) {
        if(value instanceof SatelliteInfo) {
            mInfos = ((SatelliteInfo) value).mInfos;
        } else if(value instanceof GpsLocation.SatelliteInfo[]) {
            mInfos = (GpsLocation.SatelliteInfo[]) value;
        }
        return this;
    }

    public boolean equals(Object obj) {
        if(obj instanceof SatelliteInfo) {
            if (null == mInfos) {
                return null == ((SatelliteInfo) obj).mInfos;
            } else if (null != ((SatelliteInfo) obj).mInfos && mInfos.length == ((SatelliteInfo) obj).mInfos.length){
                for (int i = 0; i < mInfos.length; i++) {
                    GpsLocation.SatelliteInfo info = mInfos[i];
                    GpsLocation.SatelliteInfo comp = ((SatelliteInfo) obj).mInfos[i];
                    if (null == info) {
                        if (null != comp) {
                            break;
                        }
                    } else if (!info.equals(comp)) {
                        break;
                    }
                }
            }
        }
        return false;
    }
}
