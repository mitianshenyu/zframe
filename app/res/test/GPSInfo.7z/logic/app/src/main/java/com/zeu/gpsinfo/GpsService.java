package com.zeu.gpsinfo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.zeu.frame.bind.Binders;

/**
 * Created by zeu on 2017/12/19.
 */

public class GpsService extends Service{
    GpsLogic mGpsLogic;
    @Override
    public void onCreate() {
        super.onCreate();
        mGpsLogic = new GpsLogic(this);
        sendBroadcast(new Intent("com.zeu.gpsinfo.GpsService.Ready"));
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return Binders.getContainer();
    }
}
