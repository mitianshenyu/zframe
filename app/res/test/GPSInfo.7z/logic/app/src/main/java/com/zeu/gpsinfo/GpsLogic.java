package com.zeu.gpsinfo;

import android.content.Context;
import android.os.Bundle;

import com.zeu.frame.bind.Data;
import com.zeu.frame.bind.observer.BooleanObserver;
import com.zeu.gpsinfo.model.GpsModel;
import com.zeu.lib.gps.GpsLocation;
import com.zeu.lib.log.Slog;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by zeu on 2017/12/19.
 */

public class GpsLogic {
    GpsModel mModel = new GpsModel();
    GpsLocation mGpsLocation;
    Timer mTimer;
    GpsLocation.Callback mGpsLocationCallback = new GpsLocation.Callback() {
        @Override
        public void onStarted() {
            super.onStarted();
        }

        @Override
        public void onStopped() {
            super.onStopped();
        }

        @Override
        public void onFirstFix(int ttffMillis) {
            super.onFirstFix(ttffMillis);
        }

        @Override
        public void onSatelliteStatusChanged(List<GpsLocation.SatelliteInfo> infos) {
            mModel.mSatelliteInfo.setLocationInfo(infos.toArray(new GpsLocation.SatelliteInfo[]{}));
            mModel.mSatelliteTotalNumber.set(infos.size());
            mModel.mSatelliteUsedNumber.set(mModel.mSatelliteInfo.getUsedSatelliteNumber());
        }
    };

    public GpsLogic(Context context) {
        mModel.attach();
        mGpsLocation = new GpsLocation(context);
        mGpsLocation.startLocation(1000, 1);
        GpsLocation.LocationInfo info = new GpsLocation.LocationInfo();
        info.longitude  = 0;
        info.accuracy  = 0;
        mModel.mLocationInfo.setLocationInfo(info);
        mGpsLocation.setOnLocationChangedListeners(new GpsLocation.OnLocationChangedListener() {
            @Override
            public void onChanged(GpsLocation.LocationInfo locationInfo) {
                mModel.mLocationInfo.setLocationInfo(locationInfo);
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {
                Slog.d("onStatusChanged");
            }

            @Override
            public void onProviderEnabled(String s) {
                Slog.d("onProviderEnabled");
            }

            @Override
            public void onProviderDisabled(String s) {
                Slog.d("onProviderDisabled");
            }
        });

        mModel.mShown.addObserver(true, new BooleanObserver() {
            @Override
            public boolean onChanged(boolean b, boolean b1, Data data) {
                if (b) {
                    //start location
                    mGpsLocation.startLocation(1000, 1);
                    mGpsLocation.setCallback(mGpsLocationCallback);
                    if (null != mTimer) {
                        mTimer.cancel();
                    }
                    mTimer = new Timer();
                    mTimer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            mModel.mLocationTime.set(mModel.mLocationTime.get()+1);
                        }
                    }, 0, 1000);
                } else {
                    //stop location
                    //mGpsLocation.stopLocation();
                    //mGpsLocation.setCallback(null);
                    /*if (null != mTimer) {
                        mTimer.cancel();
                    }
                    mModel.mLocationTime.set(0);*/
                }
                return false;
            }
        });
    }
}
