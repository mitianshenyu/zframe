package com.zeu.gpsinfo.model;

import android.os.Parcel;

import com.zeu.frame.bind.Packet;
import com.zeu.lib.gps.GpsLocation;

/**
 * Created by zeu on 2017/12/19.
 */

public class LocationInfo extends Packet {
    public GpsLocation.LocationInfo mInfo;
    public LocationInfo(String name, boolean attach) {
        super(name, null, attach);
    }

    public void setLocationInfo(GpsLocation.LocationInfo info) {
        mInfo = info;
        set(this);
    }

    protected LocationInfo(Parcel in) {
        super(in);
        try {
            mInfo = in.readParcelable(GpsLocation.LocationInfo.class.getClassLoader());
        } catch (Exception e) {}
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, 1);
        if(null != dest) {
            dest.writeParcelable(mInfo, 0);
        }
    }

    public LocationInfo copy(Object value) {
        if(value instanceof LocationInfo) {
            mInfo = ((LocationInfo) value).mInfo;
        } else if(value instanceof GpsLocation.LocationInfo) {
            mInfo = (GpsLocation.LocationInfo) value;
        }
        return this;
    }

    public boolean equals(Object obj) {
        if(obj instanceof LocationInfo) {
            if (null == mInfo) {
                return null == ((LocationInfo) obj).mInfo;
            } else {
                return mInfo.equals(((LocationInfo) obj).mInfo);
            }
        } else if(obj instanceof GpsLocation.LocationInfo) {
            if (null != mInfo) {
                return mInfo.equals(obj);
            }
        }
        return false;
    }
}
